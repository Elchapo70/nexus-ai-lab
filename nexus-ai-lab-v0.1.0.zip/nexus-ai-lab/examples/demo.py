"""Deliberately insecure example for local scanner demonstration only."""
DEBUG = True

def calculate(expression):
    return eval(expression)
