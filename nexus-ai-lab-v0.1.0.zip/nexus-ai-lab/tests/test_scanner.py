from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app
from app.scanner import scan_directory

def test_scan_finds_patterns(tmp_path: Path):
    (tmp_path / 'example.py').write_text('DEBUG = True\nvalue = eval("1+1")\n')
    result = scan_directory(tmp_path)
    assert result['files_scanned'] == 1
    assert {f['rule'] for f in result['findings']} == {'python_debug_enabled', 'unsafe_python_eval'}
    assert all('match' not in f for f in result['findings'])

def test_api_blocks_path_traversal(tmp_path, monkeypatch):
    monkeypatch.setenv('NEXUS_PROJECTS_DIR', str(tmp_path))
    client = TestClient(app)
    assert client.post('/api/scan', json={'project': '../etc'}).status_code == 422
    assert client.post('/api/scan', json={'project': 'missing'}).status_code == 404
    assert client.get('/health').json()['status'] == 'ok'

def test_api_scan(tmp_path, monkeypatch):
    (tmp_path / 'demo').mkdir()
    (tmp_path / 'demo' / 'a.py').write_text('DEBUG = True\n')
    monkeypatch.setenv('NEXUS_PROJECTS_DIR', str(tmp_path))
    client = TestClient(app)
    assert client.get('/api/projects').json()['projects'] == ['demo']
    assert client.post('/api/scan', json={'project': 'demo'}).json()['summary']['medium'] == 1

def test_symlinks_are_not_followed(tmp_path):
    (tmp_path / 'outside.py').write_text('DEBUG = True')
    (tmp_path / 'inside').mkdir()
    (tmp_path / 'inside' / 'link.py').symlink_to(tmp_path / 'outside.py')
    assert scan_directory(tmp_path / 'inside')['files_scanned'] == 0
