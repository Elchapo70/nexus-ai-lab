"""Conservative, offline, read-only source scanner."""
from __future__ import annotations
import json
import re
from pathlib import Path

MAX_FILES = 1000
MAX_FILE_BYTES = 512_000
MAX_TOTAL_BYTES = 10_000_000
IGNORED = {'.git', 'node_modules', '.venv', 'venv', '__pycache__', 'dist', 'build', '.next'}
SUFFIXES = {'.py', '.js', '.ts', '.tsx', '.jsx', '.json', '.yaml', '.yml', '.env', '.toml', '.ini', '.cfg', '.sh', '.md', '.txt'}
FINDINGS = [
    ('possible_private_key', 'high', re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'), 'Private key marker detected; remove it from source and rotate if exposed.'),
    ('possible_aws_access_key', 'high', re.compile(r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'), 'Possible AWS access key ID; verify and rotate if exposed.'),
    ('possible_hardcoded_secret', 'medium', re.compile(r'''(?im)^\s*(?:api[_-]?key|secret[_-]?key|access[_-]?token|password)\s*[:=]\s*["']?([A-Za-z0-9_./+=-]{12,})["']?\s*$'''), 'Possible hardcoded credential; use a secret manager or environment variable.'),
    ('python_debug_enabled', 'medium', re.compile(r'(?m)^\s*DEBUG\s*=\s*True\b'), 'Disable debug mode in production.'),
    ('unsafe_python_eval', 'medium', re.compile(r'\beval\s*\('), 'Review use of eval; avoid evaluating untrusted input.'),
]

def scan_directory(root: Path) -> dict:
    root = root.resolve(strict=True)
    if not root.is_dir():
        raise ValueError('Target must be a directory')
    findings = []
    scanned = 0
    skipped = 0
    total_bytes = 0
    truncated = False
    for path in sorted(root.rglob('*')):
        if not path.is_file() or any(part in IGNORED for part in path.relative_to(root).parts):
            continue
        if path.is_symlink() or path.suffix.lower() not in SUFFIXES:
            skipped += 1
            continue
        try:
            size = path.stat().st_size
            if size > MAX_FILE_BYTES or total_bytes + size > MAX_TOTAL_BYTES:
                skipped += 1
                if total_bytes + size > MAX_TOTAL_BYTES:
                    truncated = True
                    break
                continue
            if scanned >= MAX_FILES:
                truncated = True
                break
            content = path.read_text(encoding='utf-8')
        except (OSError, UnicodeError):
            skipped += 1
            continue
        scanned += 1
        total_bytes += size
        for rule, severity, regex, recommendation in FINDINGS:
            for match in list(regex.finditer(content))[:20]:
                line = content.count('\n', 0, match.start()) + 1
                findings.append({'rule': rule, 'severity': severity, 'file': path.relative_to(root).as_posix(), 'line': line, 'recommendation': recommendation})
    return {'tool': 'NEXUS AI LAB', 'version': '0.1.0', 'files_scanned': scanned, 'files_skipped': skipped, 'truncated': truncated, 'findings': findings, 'summary': {'high': sum(f['severity']=='high' for f in findings), 'medium': sum(f['severity']=='medium' for f in findings)}}

def format_report(report: dict) -> str:
    return json.dumps(report, indent=2, ensure_ascii=False)
